

def new_prefix(first, second):
    return first, second

def shift_in(tup, word):
    return tup[1], word
